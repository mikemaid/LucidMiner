#!/bin/bash
./Data/LucidMiner -mport 0 -log 0 -epool pool.lucidcoin.io:8008 -li 0 -ewal ADDRESS
